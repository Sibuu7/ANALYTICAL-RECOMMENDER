# analytical_recommendor
A rustic recommendation system bult on the RC22 dataset to showcase and analyse the shuffling and allocation of books in the dataset according to the feed.
